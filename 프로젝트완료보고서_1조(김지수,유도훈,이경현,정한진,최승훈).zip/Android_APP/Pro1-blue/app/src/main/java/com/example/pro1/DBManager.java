package com.example.pro1;

import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import android.util.Log;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


public class DBManager {
    static DBManager dbManager;
    private Handler handler;
    static Socket socket = null;
    static String ID = "";
    static String PW = "";
    static String s_tv = "";

    static String echoID = "";
    static String echoPW = "";

    static String phonenum = "";
    static String pw2="";
    static String serialnum="";



    private DBManager() {

    }

    public static DBManager getInstance() {

        if (dbManager == null)
            dbManager = new DBManager();
        return dbManager;
    }


    void setOutput(String ID, String PW) {
        DBManager.ID = ID;
        DBManager.PW = PW;
        Login mlogin = new Login();
        Log.w("로그", "버튼이 눌려짐");
        mlogin.start();
    }

    void setdate(String s_tv){
        DBManager.s_tv=s_tv;
        Date mdate=new Date();
        mdate.start();
    }
    void setOutput2(String ID, String PW, String SN) {
        DBManager.phonenum = ID;
        DBManager.pw2 = PW;
        DBManager.serialnum = SN;
        Log.w("로그", "회원가입 버튼이 눌러짐");
        SingUp mSingUp = new SingUp();
        mSingUp.start();
    }


}

class Login extends Thread {
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();


        try {
            Log.w("로그", "아이디 판별 진입");
            mSocketThread.write("1");

            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String Lbtn = br1.readLine(); // 대기하다 서버에서 판별값을 받음 // 변경 전
            Log.w("로그", ""+Lbtn);


            mSocketThread.write(DBManager.ID); // 변경된 구문
            Log.w("로그", "보낸 아이디"+ DBManager.ID);

            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID = br2.readLine(); // 대기하다 서버에서 판별값을 받음 // 변경 전
            MainActivity.TrueID = echoID;

            Log.w("로그 서버에서 받은 ID 판별 값 : ", "" + echoID);


            if (echoID.equals("1")) { // 입력한 ID가 맞다면 진입
                readData = null;

                Log.w("로그", "패스워드 판별 진입");
                mSocketThread.write(DBManager.PW); // 변경된 구문 // 입력된 PW 서버에 보냄


                Log.w("로그", "" + DBManager.PW);


                InputStream in3 = SocketThread.socket.getInputStream();
                BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
                String echoPW = br3.readLine(); // 대기하다 서버에서 판별값을 받음
                MainActivity.TruePW = echoPW;  // 판별값을 MAIN 에서 사용하는 매개변수에 저장


                Log.w("로그 서버에서 받은 PW 판별 값 : ", "" + echoPW);
            }

            else if(echoID.equals("0")) {
                MainActivity.TruePW = "0";
                Log.w("로그", "PW 판별 값 : " + MainActivity.TruePW);
            }
            else if(echoID.equals("")) {
                MainActivity.TruePW = "";
                Log.w("로그 : ", "PW 판별 값 :"+ MainActivity.TruePW );
            }


        } catch (Exception e) {
            e.printStackTrace();
            Log.w("로그 버퍼", "버퍼생성 잘못됨");
        }
        Log.w("로그 버퍼", "버퍼생성 잘됨");
    }
}



class SingUp extends  Thread{    // 회원가입 소켓 통신
    SocketThread mSocketThread = SocketThread.get();
    String readData = null;

    @Override
    public void run() {
        super.run();

        try {

            Log.w("로그", "회원가입 클래스 진입");  // 버튼을 판별하기 위한 소켓 통신
            mSocketThread.write("2");
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String Lbtn = br1.readLine();
            Log.w("로그", ""+Lbtn);

            Log.w("로그", "Server로 보낸 시리얼 번호"+DBManager.serialnum);
            mSocketThread.write(DBManager.serialnum); // 시리얼 넘버
            InputStream in4 = SocketThread.socket.getInputStream();
            BufferedReader br4 = new BufferedReader(new InputStreamReader(in4));
            String SN = br4.readLine();
            Log.w("로그", "" + SN);

            Log.w("로그", "Server로 보낸 핸드폰 번호"+DBManager.phonenum);
            mSocketThread.write(DBManager.phonenum); // 핸드폰 번호
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String PH = br2.readLine();
            Log.w("로그", "" + PH);

            Log.w("로그", "Server로 보낸 비밀 번호"+DBManager.pw2);
            mSocketThread.write(DBManager.pw2); // 비밀 번호
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String PW = br3.readLine();
            Log.w("로그", "" + PW);




        }catch (Exception e) {

        }
    }
}

class Date extends Thread{
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();

        try{
            mSocketThread.write("3");

            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine();
            Log.d("TEST", ""+echoID);

            mSocketThread.write(DBManager.s_tv);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoDate = br2.readLine();
            Log.d("TEST", ""+echoDate);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
