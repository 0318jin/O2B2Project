package com.example.pro1;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper{


    public DatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE mytable"+"(number integer primary key autoincrement,"+"ID text,date text);";
        db.execSQL(sql);
        String sql2 = "CREATE TABLE schdule" + "(ID text,date_text text,s_subnum text,s_time text);";
        db.execSQL(sql2);
        String sql3 = "CREATE TABLE addfr"+"(ID text,name text," + "st_time integer);";
        db.execSQL(sql3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "drop table mytable;"; // 테이블 드랍
        db.execSQL(sql);
        onCreate(db);

        String sql2 = "drop table schdule;"; // 테이블 드랍
        db.execSQL(sql2);
        onCreate(db);

        String sql3 = "drop table addfr;"; // 테이블 드랍
        db.execSQL(sql3);
        onCreate(db);
    }
}
