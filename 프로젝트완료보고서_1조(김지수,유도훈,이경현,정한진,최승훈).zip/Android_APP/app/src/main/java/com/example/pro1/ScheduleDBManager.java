package com.example.pro1;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;
import android.view.inputmethod.InputMethodManager;

import java.util.concurrent.ExecutionException;

import static android.app.Activity.RESULT_OK;

public class ScheduleDBManager {
    private DatabaseHelper helper;
    int dbVersion = 3; // 데이터베이스 버전
    static SQLiteDatabase db;
    String tag = "SQLite";



    boolean setScheduleDB(Context mContext, String tableName, String dbName) {
        helper = new DatabaseHelper(
                mContext,  // 현재 화면의 제어권자
                dbName,// db 이름
                null,  // 커서팩토리-null : 표준커서가 사용됨
                dbVersion);       // 버전
        try {
            db = helper.getWritableDatabase(); // 읽고 쓸수 있는 DB
            //db = helper.getReadableDatabase(); // 읽기 전용 DB select문
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e(tag, "데이터베이스를 얻어올 수 없음");
            return false;
        }
        return true;


    }



    void select(String tableName) {
        int id=0;
//        Cursor c = db.query(tableName, null, null, null, null, null, null);
        Cursor c = db.rawQuery("SELECT * FROM "+tableName+" WHERE ID='"+DBManager.ID+"'",null);

        if(c.getColumnCount()>0) {
            Log.d("test","if");
            while (c.moveToNext()) {
                String date = c.getString(2);
                id++;
//                schedule.tv.append("\n" + "♥" + "date:" + date);
                schedule.heart.append(id+"\n");
                schedule.scheduledate.append(date+"\n");
                Log.d("test","while");
            }

        }
    }

    void insert(String ID,String date, String tableName) {
        ContentValues values = new ContentValues();
        // 키,값의 쌍으로 데이터 입력
        values.put("ID", ID);
        values.put("date", date);

        long result = db.insert(tableName, null, values);
        Log.d(tag, "입력 성공했음");
//        schedule.scheduledate.setText(result+"입력 성공했음");
        select(tableName);
    }

    void delete(String s_date, String tableName) {

        int result = db.delete(tableName, "date=?", new String[]{s_date});

        Log.d(tag, result + "개 row delete 성공");

//        schedule.scheduledate.setText(result + "개 row delete 성공");
        select(tableName);
    }
    //일정추가하는 insert select delete문
//    static int num=1;
    void DBselect(String tableName2) {
        int id=0;int count=0;
        Log.d("test","커서문 못넘음");

//        Cursor c = db.query(tableName2, null, null, null, null, null, null);
        Cursor c = db.rawQuery("SELECT * FROM "+tableName2+" WHERE ID='"+DBManager.ID+"'",null);

        Log.d("test","커서문 넘음");
//        num=0;

        if(c.getColumnCount()>0) {
            while (c.moveToNext()) {
                count++;

            }
            c.moveToPosition(count - 11);

        }

        while (c.moveToNext()) {

            id++;
            String date_text = c.getString(1);
            String s_subnum = c.getString(2);
            String s_time = c.getString(3);


            schedule.DBid.append(id+"\n");
            schedule.DBdate.append(date_text+"\n");
            schedule.DBsub.append(s_subnum + "개\n");
            schedule.DBtime.append( s_time + "시간\n");

        }
        Log.d("test", "행추가클릭");
    }

    void DBinsert(String ID,String date_text, String s_subnum, String s_time, String tableName) {
        ContentValues values = new ContentValues();
        // 키,값의 쌍으로 데이터 입력
        values.put("ID", ID);
        values.put("date_text", date_text);
        values.put("s_subnum", s_subnum);
        values.put("s_time", s_time);

        long result = db.insert(tableName, null, values);
        Log.d(tag, "입력 성공했음");

        schedule.textView.setText("총 입력된 날 : "+result+" 입력 성공했음");

        Log.d("test", "" + date_text);
        Log.d("test", "" + s_subnum);
        Log.d("test", "" + s_time);

        Log.d("test", "" + result);


    }//공부계획추가하는 인서트문


    void inserfrd(String ID,String name, int st_time, String tableName) {
        ContentValues values = new ContentValues();

        Log.d(tag, "입력 들어옴");
        // 키,값의 쌍으로 데이터 입력
        values.put("ID", ID);
        values.put("name", name);
        values.put("st_time", st_time);

        long result = db.insert(tableName, null, values);
        Log.d(tag, result+"입력 성공했음");
    }


    int count=0;
    void selectfrd(String tableName){
        schedule.FrRank.setText("");
        schedule.FrRankName.setText("");
        schedule.FrRanktime.setText("");
        int rank=0;
        Cursor c = db.rawQuery("SELECT * FROM "+tableName+" WHERE ID='"+DBManager.ID+"'"+" ORDER BY st_time desc",null);
        if(c.getColumnCount()>0) {
            while (c.moveToNext()) {
                count++;

            }
            c.moveToPosition(count - 11);
        }
        Log.d("test", "커서 열림");
        while (c.moveToNext()) {
            rank++;
            String s_name=c.getString(1);
            int s_sttime=c.getInt(2);

            schedule.FrRank.append(rank+".\n");
            schedule.FrRankName.append(s_name+"\n");
            schedule.FrRanktime.append(s_sttime+"시간\n");
        }

    }
    int i=0;
    void check(String tableName){

        Cursor c = db.rawQuery("SELECT * FROM "+tableName+" WHERE ID = '" + DBManager.ID + "' and name = '나' ",null);
        while (c.moveToNext()) {
            i++;
           Log.d("test","i:"+i);
        }
    }

    static int realtime;
    void selectMy(String tableName){
        int count = 0;
        try {
            Thread.sleep(250);

            while(true) {
                if(count == 10) {
                    break;
                }
                count++;
            }

        }catch (Exception e) {
            e.printStackTrace();
        }

        check(tableName);

        if( i <= 0) {
            inserfrd(DBManager.ID, "나", realtime, tableName);
        }else {
            db.execSQL(" update " + tableName + " set st_time = '"+ realtime +"' where name = '나' and ID= '"+DBManager.ID + "'" );
//            ContentValues values = new ContentValues();
//            values.put("realtime",realtime);
//            db.update(tableName,values,"name=나",null);

            Log.d("test", "selectMy 들어옴");
            schedule.MyRankName.setText("");
            schedule.MyRankTime.setText("");
            String time = Integer.toString(realtime);
            schedule.MyRankTime.append(time + "시간");
            Log.d("test", "MyRank.mytime:" + time);
//        schedule.MyRank.append();
        }
    }


}
