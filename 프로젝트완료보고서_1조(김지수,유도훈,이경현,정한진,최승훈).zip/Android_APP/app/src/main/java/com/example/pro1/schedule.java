package com.example.pro1;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class schedule extends AppCompatActivity {
    static int st_time = 0;
    private LineChart lineChart;
    private BarChart chart;
    private BackPressCloseHandler2 backPressCloseHandler2;        // 처음 화면으로 되돌아가는 기능

    String dbName = "st_file.db";
    String dbName2 = "schedule.db";
    String tag = "SQLite";
    String tableName = "mytable";
    String tableName2 = "schdule";
    String dbName3 = "addfrd.db";
    String tableName3 = "addfr";
    EditText date;
    static TextView tv;//db에 저장된거 보여주는곳
    Button binsert, bselect, bdelete;
    Button addfrdbtn, studyadd;//팝업창을위한거
    static int scCount = 0; // onStop 생명주기 판별하기위한 매개변수


    static TextView DBdate, DBtime, DBsub, DBid;
    static TextView textView, FrRank, FrRankName, FrRanktime,heart,scheduledate;
    static TextView MyRankName,MyRankTime;

    ArrayList<BarEntry> BARENTRY;
    ArrayList<String> BarEntryLabels;
    BarDataSet Bardataset;
    BarData BARDATA;

    ArrayList<Integer> xAXES = new ArrayList<>();
    ArrayList<Entry> Arr_RealStudy = new ArrayList<>();     // 실제 학습 시간 ArrayList
    ArrayList<Entry> Arr_Schedule = new ArrayList<>();      // 스케줄 ArrayList


    final int REQUEST_TEST = 1;
    final int REQUEST_ADD_FRD = 2;

    String[] sp_Arr_Schedule; // 차트
    String[] sp_Arr_RealStudy;// 차트
    ArrayList<Float> sp_Arr_efficiency = new ArrayList<>(); // 효율을 계산한것을 넣을 ArrayList

    @Override
    public void onCreate(Bundle savedInstanceState) {
        scCount = 0; // onStop 생명주기 판별하기위한 매개변수
        backPressCloseHandler2 = new BackPressCloseHandler2(this);  // 처음 화면으로 되돌아가는 기능

        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);

        FrRank = (TextView) findViewById(R.id.FrRank);
        FrRankName = (TextView) findViewById(R.id.FrRankName);
        FrRanktime = (TextView) findViewById(R.id.FrRankTime);

        MyRankName = (TextView) findViewById(R.id.MyRankName);
        MyRankTime = (TextView) findViewById(R.id.MyRankTime);

        textView = (TextView) findViewById(R.id.textview);
        DBdate = (TextView) findViewById(R.id.DBdate);
        DBid = (TextView) findViewById(R.id.DBid);
        DBsub = (TextView) findViewById(R.id.DBsub);
        DBtime = (TextView) findViewById(R.id.DBtime);
        scheduledate=(TextView)findViewById(R.id.scheduledate);
        heart=(TextView)findViewById(R.id.heart);


        final ScheduleDBManager mDB3 = new ScheduleDBManager();
        boolean isDBConnect3 = mDB3.setScheduleDB(this, tableName3, dbName3);
        if (!isDBConnect3)
            finish();

        mDB3.selectMy(tableName3);//내꺼 기록조회
        mDB3.selectfrd(tableName3);


        lineChart = (LineChart) findViewById(R.id.chart1); // 라인차트
        chart = (BarChart) findViewById(R.id.chart2);      // 바 차트

        addfrdbtn = (Button) findViewById(R.id.addfrdbtn);
        addfrdbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("test", "친구추가버튼클릭");
                scCount++;
                Intent intent = new Intent(getApplicationContext(), add_frd.class);
                startActivityForResult(intent, REQUEST_ADD_FRD);


            }
        });


        studyadd = (Button) findViewById(R.id.studyadd);
        studyadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("test", "추가버튼클릭");
                scCount++;
                Intent intent = new Intent(getApplicationContext(), study_add.class);
                startActivityForResult(intent, REQUEST_TEST);

            }
        });


        date = (EditText) findViewById(R.id.date);

        TabHost tabHost = (TabHost) findViewById(R.id.tabHost1);
        tabHost.setup();

        ImageView tabw1=new ImageView(this);
        tabw1.setImageResource(R.drawable.tab_01);

        ImageView tabw2=new ImageView(this);
        tabw2.setImageResource(R.drawable.tab_02);

        ImageView tabw3=new ImageView(this);
        tabw3.setImageResource(R.drawable.tab_03);

        // 첫 번째 Tab. (탭 표시 텍스트:"TAB 1"), (페이지 뷰:"content1")
        TabHost.TabSpec ts1 = tabHost.newTabSpec("Tab Spec 1");
        ts1.setContent(R.id.content1);
        ts1.setIndicator(tabw1);
        tabHost.addTab(ts1);

        // 두 번째 Tab. (탭 표시 텍스트:"TAB 2"), (페이지 뷰:"content2")
        TabHost.TabSpec ts2 = tabHost.newTabSpec("Tab Spec 2");
        ts2.setContent(R.id.content2);
        ts2.setIndicator(tabw2);
        tabHost.addTab(ts2);

        // 세 번째 Tab. (탭 표시 텍스트:"TAB 3"), (페이지 뷰:"content3")
        TabHost.TabSpec ts3 = tabHost.newTabSpec("Tab Spec 3");
        ts3.setContent(R.id.content3);
        ts3.setIndicator(tabw3);
        tabHost.addTab(ts3);

        DisplayMetrics metrics=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int screenHeight=metrics.heightPixels;
        tabHost.getTabWidget().getChildAt(0).getLayoutParams().height=(screenHeight*15)/200;
        tabHost.getTabWidget().getChildAt(1).getLayoutParams().height=(screenHeight*15)/200;
        tabHost.getTabWidget().getChildAt(2).getLayoutParams().height=(screenHeight*15)/200;

//        tv = (TextView) findViewById(R.id.textView4);
//        tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        heart.setMovementMethod(ScrollingMovementMethod.getInstance());
        scheduledate.setMovementMethod(ScrollingMovementMethod.getInstance());
        binsert = (Button) findViewById(R.id.insert);
        bselect = (Button) findViewById(R.id.select);
        bdelete = (Button) findViewById(R.id.delete);


        final ScheduleDBManager mDB2 = new ScheduleDBManager();
        boolean isDBConnect2 = mDB2.setScheduleDB(this, tableName2, dbName2);
        if (!isDBConnect2)
            finish();


        mDB2.DBselect(tableName2);

        final ScheduleDBManager mDB = new ScheduleDBManager();
        boolean isDBConnect = mDB.setScheduleDB(this, tableName, dbName);
        if (!isDBConnect)
            finish();

        mDB.select(tableName);//앱 키자마자 일정조회

        binsert.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View v) {
                String s_date = date.getText().toString();

                if ("".equals(s_date)) {
//                    tv.setText("insert 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }
                heart.setText("");
                scheduledate.setText("");
                mDB.insert(DBManager.ID, s_date, tableName);

                Toast.makeText(getApplicationContext(), "입력성공", Toast.LENGTH_SHORT).show();

//                mDB.select(tableName);

                date.setText("");


            }
        });

        bselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                tv.setText("");//기존에 textView에 있는 값을 지우고 보여주기
                heart.setText("");
                scheduledate.setText("");
                mDB.select(tableName);
                date.setText("");//입력창에있는거 지우기

                InputMethodManager imm =
                        (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow
                        (getCurrentFocus().getWindowToken(), 0);
            }
        });


        bdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s_date = date.getText().toString();

                if ("".equals(s_date)) {
//                    tv.setText("delete 실패 - 항목을 입력하세요");
                    return;// 그냥 빠져나감
                }
                heart.setText("");
                scheduledate.setText("");
                mDB.delete(s_date, tableName);
                Toast.makeText(getApplicationContext(), "삭제성공", Toast.LENGTH_SHORT).show();

                date.setText("");


            }
        });


        /////////////////////////////////////////////////라인 차트///////////////////////////////////////////////////////////////////
        while (true) {
            try {
                Thread.sleep(250);
                break;
            } catch (Exception e) {

            }
        }

        sp_Arr_Schedule = DBManager.schedule_data.split("/");
        sp_Arr_RealStudy = DBManager.Realstudy_data.split("/");

        for (int i = 0; i < 7; i++) {   // i 값을 학습 테이블의 길이만큼 하면 될테고....
            int date = i;            // 가장 최근의 7일만 가져오기로
            int Schedule = (int)Float.parseFloat(sp_Arr_Schedule[i]);      // 각각의 스케줄 학습 테이블의 시간을 가져오면 될테고....
            int RealStudy = (int)Float.parseFloat(sp_Arr_RealStudy[i]);     // 각각의 실제 학습 테이블의 시간을 가져오면 될테고....

            Log.w("test", "real : "+RealStudy);

            Arr_Schedule.add(new Entry(Schedule, date));
            Arr_RealStudy.add(new Entry(RealStudy, date));

            xAXES.add(i, Integer.valueOf(i + 1));
        }

        String[] xaxes = new String[xAXES.size()];
        for (int i = 0; i < xAXES.size(); i++) {
            xaxes[i] = xAXES.get(i).toString();   // 아래그림의 동그란 부분에 표시되는 x축 값.
        }

        ArrayList<LineDataSet> lineDataSets = new ArrayList<>();

        //아래 그림의 파란색 그래프
        LineDataSet lineDataSet1 = new LineDataSet(Arr_RealStudy, "실제"); // 데이터, 범례 (ArrayList, label)
        lineDataSet1.setValueTextSize(10);
        lineDataSet1.setDrawCircles(true); // 값의 점 표시 여부
        lineDataSet1.setCircleColor(0);    // 점 색상
        lineDataSet1.setCircleSize(6);     // 점 크기
        lineDataSet1.setColor(Color.BLUE); // 라인 색상
        lineDataSet1.setLineWidth(3); // 라인 두께
        lineDataSet1.setDrawCubic(true); // 선에 곡률 적용

        //아래 그림의 빨간색 그래프
        LineDataSet lineDataSet2 = new LineDataSet(Arr_Schedule, "계획"); // 데이터, 범례 (ArrayList, label)
        lineDataSet2.setValueTextSize(10);
        lineDataSet2.setDrawCircles(true); // 값의 점 표시 여부
        lineDataSet2.setCircleColor(0);    // 점 색상
        lineDataSet2.setCircleSize(6);     // 점 크기
        lineDataSet2.setColor(Color.YELLOW); // 라인 색상
        lineDataSet2.setLineWidth(3); // 라인 두께
        lineDataSet2.setDrawCubic(true);// 선에 곡률 적용

        lineDataSets.add(lineDataSet1); // 생성한 라인 추가
        lineDataSets.add(lineDataSet2); // 생성한 라인 추가

        XAxis xAxis1 = lineChart.getXAxis();           // X축 설정
        xAxis1.setPosition(XAxis.XAxisPosition.BOTTOM);

        YAxis yAxisRight = lineChart.getAxisRight(); //Y축의 오른쪽면 설정
        yAxisRight.setDrawLabels(false);    //제거
        yAxisRight.setDrawAxisLine(false);  //제거
        yAxisRight.setDrawGridLines(false); //제거

        lineChart.setDescription("OBA-Study");
        lineChart.setData(new LineData(xaxes, lineDataSets));
        lineChart.setDoubleTapToZoomEnabled(false);
//        lineChart.setVisibleXRangeMaximum(60 * 60 * 24 * 1000 * 5); //
        lineChart.animateY(3000);
/////////////////////////////////////////라인 차트//////////////////////////////////////////////////////////


// ///////////////////////////////////////바 차트 ////////////////////////////////////////////////////////

        Log.w("로그", "바 차트");

        for (int i = 0; i < 7; i++) {
            sp_Arr_efficiency.add(((Float.parseFloat(sp_Arr_RealStudy[i]) / Float.parseFloat(sp_Arr_Schedule[i])) * 100));
        }

        TextView textView1 = (TextView) findViewById(R.id.txt);

        if (sp_Arr_efficiency.get(6) >= 90) {
            textView1.setText("달성율이 " + sp_Arr_efficiency.get(6) + "%로 완벽한 계획수행입니다. 계획한일과 시간의 분배가 완벽합니다. 내일의 계획을 짤때는 시간을 단축시키거나 공부량을 늘려보는건 어떨까요?\n");
        } else if (90 > sp_Arr_efficiency.get(6)  && sp_Arr_efficiency.get(6) >= 70) {
            textView1.setText("달성율이 " + sp_Arr_efficiency.get(6) + "%로 우수한 편입니다. 계획한 일을 조금 남기고 하루가 끝나버렸네요 100%가 눈앞에 있으니 내일은 더 힘내보세요.\n");
        } else if (70 > sp_Arr_efficiency.get(6) && sp_Arr_efficiency.get(6) >= 50) {
            textView1.setText("달성율이 " + sp_Arr_efficiency.get(6) + "%로 보통인 편입니다. 계획한 일을 달성하는데 너무 많은 시간을 소요하고 있는건 아닌지 돌아보아야 합니다.\n");
        } else if (50 > sp_Arr_efficiency.get(6) && sp_Arr_efficiency.get(6) >= 30) {
            textView1.setText("달성율이 " + sp_Arr_efficiency.get(6) + "%로 낮은 편입니다. 너무 많은 일을 계획하지는 않았는지, 시간의 분배에 실패한 것은 아닐지 확인해 보세요.\n");
        } else if (30 > sp_Arr_efficiency.get(6) && sp_Arr_efficiency.get(6) > 0) {
            textView1.setText("달성율이 " + sp_Arr_efficiency.get(6) + "%로 매우 낮은 편입니다. 계획한 일을 거의 완수하지 못했습니다. 너무 많은 계획을 세우기 보다는 작은 계획부터 세워서 하나하나 완수해 나가도록 하세요.\n");
        } else{
            textView1.setText("7일간의 학습 데이터가 없습니다. 학습을 진행해주시기 바랍니다!\n");
//           while(true) {
//               int i = 5;
//                if (sp_Arr_efficiency.get(i) >= 90) {
//                    textView1.setText("달성율이 " + sp_Arr_efficiency.get(i) + "%로 완벽한 계획수행입니다. 계획한일과 시간의 분배가 완벽합니다. 내일의 계획을 짤때는 시간을 단축시키거나 공부량을 늘려보는건 어떨까요?\n");
//                    break;
//                } else if (90 > sp_Arr_efficiency.get(i) && sp_Arr_efficiency.get(6) >= 70) {
//                    textView1.setText("달성율이 " + sp_Arr_efficiency.get(i) + "%로 우수한 편입니다. 계획한 일을 조금 남기고 하루가 끝나버렸네요 100%가 눈앞에 있으니 내일은 더 힘내보세요.\n");
//                    break;
//                } else if (70 > sp_Arr_efficiency.get(i) && sp_Arr_efficiency.get(6) >= 50) {
//                    textView1.setText("달성율이 " + sp_Arr_efficiency.get(i) + "%로 보통인 편입니다. 계획한 일을 달성하는데 너무 많은 시간을 소요하고 있는건 아닌지 돌아보아야 합니다.\n");
//                    break;
//                } else if (50 > sp_Arr_efficiency.get(i) && sp_Arr_efficiency.get(6) >= 30) {
//                    textView1.setText("달성율이 " + sp_Arr_efficiency.get(i) + "%로 낮은 편입니다. 너무 많은 일을 계획하지는 않았는지, 시간의 분배에 실패한 것은 아닐지 확인해 보세요.\n");
//                    break;
//                } else if (30 > sp_Arr_efficiency.get(i) && sp_Arr_efficiency.get(6) > 0) {
//                    textView1.setText("달성율이 " + sp_Arr_efficiency.get(i) + "%로 매우 낮은 편입니다. 계획한 일을 거의 완수하지 못했습니다. 너무 많은 계획을 세우기 보다는 작은 계획부터 세워서 하나하나 완수해 나가도록 하세요.\n");
//                    break;
//                } else if(i == 0) {
//                    textView1.setText("금일 학습 스케줄 또는 실제학습 데이터중 한 데이터가 없습니다. 학습을 진행해 주세요!");
//                    break;
//                }
//                i--;
//            }
        }

        BARENTRY = new ArrayList<>();
        BarEntryLabels = new ArrayList<String>();

        AddValuesToBARENTRY(); // 값을 넣음
        AddValuesToBarEntryLabels(); // X축 라벨

        Bardataset = new BarDataSet(BARENTRY, "공부 효율 %");
        BARDATA = new BarData(BarEntryLabels, Bardataset); //
        Bardataset.setColors(Collections.singletonList(Color.YELLOW)); // 바차트 색상
        chart.setData(BARDATA);
        chart.animateY(3000); // 애니메이션 기능
        chart.setDoubleTapToZoomEnabled(false); // 더블탭 기능 제거
        chart.setDescription("OBA-Study"); // 아래 글자 태그

        XAxis xAxis2 = chart.getXAxis();
        xAxis2.setPosition(XAxis.XAxisPosition.BOTTOM); // X축 태그를 아래로 배치

    }

    public void AddValuesToBARENTRY() { // 값을 넣는 함수

        for (int i = 0; i < sp_Arr_efficiency.size(); i++) {
            BARENTRY.add(new BarEntry((float) sp_Arr_efficiency.get(i), i)); // Y, X
        }
    }

    public void AddValuesToBarEntryLabels() { // X 축 라벨


        for (int i = 0; i < 7; i++) {
            BarEntryLabels.add(String.valueOf(i + 1));
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        final ScheduleDBManager mDB2 = new ScheduleDBManager();
        boolean isDBConnect2 = mDB2.setScheduleDB(this, tableName2, dbName2);
        if (!isDBConnect2)
            finish();

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_TEST) {
            if (resultCode == RESULT_OK) {

                DBdate.setText("");
                DBsub.setText("");
                DBtime.setText("");
                DBid.setText("");
                mDB2.DBselect(tableName2);

            } else {   // RESULT_CANCEL
                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
            }

        }
        final ScheduleDBManager mDB = new ScheduleDBManager();
        boolean isDBConnect = mDB.setScheduleDB(this, tableName3, dbName3);
        if (!isDBConnect)
            finish();
        if (requestCode == REQUEST_ADD_FRD) {
            if (resultCode == RESULT_OK) {
                //데이터 가져옴..

                int count = 0;

                while (true) {
                    try {
                        Thread.sleep(250);
                        count++;
                        if(count == 5) {
                            break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }




//                    int st_time = Integer.parseInt(fr_add.s_realT);
                Log.d("test", "st_time" + st_time);
                if(st_time == -1){
                    Toast.makeText(this, "없는 아이디입니다." , Toast.LENGTH_SHORT).show();
                }else {
                    mDB.inserfrd(DBManager.ID, data.getStringExtra("savename"), st_time, tableName3);
                    Toast.makeText(this, "입력완료! 저장된이름:" + data.getStringExtra("savename"), Toast.LENGTH_SHORT).show();
                    mDB.selectfrd(tableName3);
                }

            }
        }


    }

    @Override
    protected void onStop() { // 앱 을 창을내려 종료했을 경우 소켓을 닫기위한 onStop
        super.onStop();
        Log.w("로그", "앱이 꺼졌습니다. 소켓을 닫겠습니다.. onStop");
        if (scCount == 0) { // onStop 생명주기 판별하기위한 매개변수
            mThreadSendEndSocket mThreadSendEndSocket = new mThreadSendEndSocket();
            mThreadSendEndSocket.start();
        } else if (scCount == 1) {
            Log.w("로그", "화면 페이지 이동.");
        }

    }

    @Override
    public void onBackPressed() { // 처음화면으로 되돌아가는 기능
        backPressCloseHandler2.onBackPressed();
    }
}




