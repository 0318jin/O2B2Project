package com.example.pro1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    final int ID = 1234;
    final int PW = 5678;

    EditText IPID, IPPW;
    String sId, sPw;
    int count = 0;

    static String TrueID = "";
    static String TruePW = "";

    private String html = "";
    private Handler mHandler;

    private BackPressCloseHandler backPressCloseHandler; // 로그인화면에서 뒤로가기 버튼을 두번 눌렀을 시 앱 종료

    static int desCount = 0;
    static int exitCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        backPressCloseHandler = new BackPressCloseHandler(this); // 로그인화면에서 뒤로가기 버튼을 두번 눌렀을 시 앱 종료

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SocketThread m = SocketThread.get();
        m.connect();
        Log.d("로그 : settext", "------------연결됨");


        TextView joinbtn = findViewById(R.id.joinbtn);
        Button loginbtn = findViewById(R.id.loginbtn);

        IPID = (EditText) findViewById(R.id.ipid);
        IPPW = (EditText) findViewById(R.id.ippw);


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sId = IPID.getText().toString();
                sPw = IPPW.getText().toString();
                Log.d("settext", "------------");
                DBManager m = DBManager.getInstance();
                m.setOutput(sId, sPw);


                while (true) {
                    try {
                        Thread.sleep(250);
                    } catch (Exception e) {

                    }
            if (MainActivity.TrueID.equals("1") && MainActivity.TruePW.equals("1")) {
                        Log.w("로그", "ID 과 PW 를 True 받음");
                        break;
                    } else if (count == 5) {
                        Log.w("로그 :ID count", "count : " + count);
                        break;
                    } else
                        count++;
                }
                count = 0;
                Log.w("로그", "아이디 판정값 : " + MainActivity.TrueID);
                Log.w("로그", "비밀번호 판정값 : " + MainActivity.TruePW);


                if (MainActivity.TrueID.equals("") || MainActivity.TruePW.equals("")) {
                    Toast.makeText(MainActivity.this, "값이 없습니다.", Toast.LENGTH_LONG).show();

                } else if (MainActivity.TrueID.equals("1") && MainActivity.TruePW.equals("1")) {
                    Intent intent = new Intent(getApplicationContext(), schedule.class);
                    Log.w("로그", "로그인 완료");
                    desCount++;
                    startActivity(intent);
                    finish();

                } else if (!(MainActivity.TrueID.equals("1") && MainActivity.TruePW.equals("1"))) {
                    Toast.makeText(MainActivity.this, "id나 비밀번호가 틀렸습니다.", Toast.LENGTH_LONG).show();

                }

            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), join.class);
                startActivity(intent);
                desCount++;
                finish();
            }
        });
    }


    @Override
    public void onBackPressed() { // 로그인화면에서 뒤로가기 버튼을 두번 눌렀을 시 앱 종료
        backPressCloseHandler.onBackPressed();
    }

    @Override
    protected void onDestroy() { // 앱이 화면넘김이나 뒤로가기로 종료되었을 경우
        super.onDestroy();
        if (desCount == 0) {

            Log.w("로그", "Main_onDestroy : App이 종료됨.");
            mThreadSendEndSocket mThreadSendEndSocket = new mThreadSendEndSocket();
            mThreadSendEndSocket.start();
            int count = 0;
            try {
                while (count < 600) {
                    Thread.sleep(500);
                    if (SocketThread.socketEndState) {
                        Log.w("로그", "정상종료.");
                        break;
                    }
                }
            } catch (Exception e) {
                Log.d("ERROR", "exception!!! ");
            }

            Log.w("로그", "서버에 메시지 날림.");

        } else if (desCount == 1) {
            Log.w("로그", "Main_onDestroy : 다른 화면으로 넘어감.");
        }
    }

    @Override
    protected void onStop() { // 앱이 창을 내려서 종료할경우.
        super.onStop();
        if (desCount == 0) {
            Log.w("로그", "App이 강제종료 되었습니다.");
            mThreadSendEndSocket mThreadSendEndSocket = new mThreadSendEndSocket();
            mThreadSendEndSocket.start();

            int count = 0;

            try {
                while (count < 600) {
                    Thread.sleep(500);
                    if (SocketThread.socketEndState) {
                        Log.w("로그", "정상종료.");
                        break;
                    }
                }
            } catch (Exception e) {
                Log.d("ERROR", "exception!!! ");
            }

            Log.w("로그", "서버에 메시지 날림.");
        } else if(desCount == 1) {
            Log.w("로그", "페이지가 넘어가며 전 액티비티가 종료되었습니다.");
        }
    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        SocketThread m = SocketThread.get();
//        m.connect();
//    }
}

class mThreadSendEndSocket extends Thread {
    @Override
    public void run() {
        super.run();
        SocketThread mSocketThread = SocketThread.get();
        mSocketThread.write("7");
    }
}




