package com.example.pro1;

import android.os.Handler;
import android.os.Message;
import android.widget.Toast;
import android.util.Log;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


public class DBManager {
    static DBManager dbManager;
    private Handler handler;
    static Socket socket = null;
    static String ID = "";
    static String PW = "";
    static String s_tv = "";
    static String mytime = "";

    static String echoID = "";
    static String echoPW = "";

    static String phonenum = "";
    static String pw2="";
    static String serialnum="";
    static String  fpnum= "";

    static String schedule_data = null;
    static String Realstudy_data = null;



    private DBManager() {

    }

    public static DBManager getInstance() {

        if (dbManager == null)
            dbManager = new DBManager();
        return dbManager;
    }


    void setOutput(String ID, String PW) {
        DBManager.ID = ID;
        DBManager.PW = PW;
        Login mlogin = new Login();
        Log.w("로그", "버튼이 눌려짐");
        mlogin.start();
    }

    void setdate(String s_tv){
        DBManager.s_tv=s_tv;
        Date mdate=new Date();
        mdate.start();
    }
    void setOutput2(String ID, String PW, String SN) {
        DBManager.phonenum = ID;
        DBManager.pw2 = PW;
        DBManager.serialnum = SN;
        Log.w("로그", "회원가입 버튼이 눌러짐");
        SingUp mSingUp = new SingUp();
        mSingUp.start();
    }
    void setOutput3(String fpnum) {
        DBManager.fpnum = fpnum;

        Log.w("로그", "친구추가 버튼이 눌러짐");
        fr_add mfr_add = new fr_add();
        mfr_add.start();
    }
//    void setOutput4(String ID){
//        DBManager.ID=ID;
//
//        Log.w("로그", "친구추가창에서 내기록 조회");
//        MyRank myRank=new MyRank();
//        myRank.start();
//
//    }

}

class Login extends Thread {
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;
    static String mytime;
    @Override
    public void run() {
        super.run();


        try {
            Log.w("로그", "아이디 판별 진입");
            mSocketThread.write("1");

            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String Lbtn = br1.readLine(); // 대기하다 서버에서 판별값을 받음 // 변경 전
            Log.w("로그", ""+Lbtn);


            mSocketThread.write(DBManager.ID); // 변경된 구문
            Log.w("로그", "보낸 아이디"+ DBManager.ID);

            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID = br2.readLine(); // 대기하다 서버에서 판별값을 받음 // 변경 전
            MainActivity.TrueID = echoID;

            Log.w("로그 서버에서 받은 ID 판별 값 : ", "" + echoID);


            if (echoID.equals("1")) { // 입력한 ID가 맞다면 진입
                readData = null;

                Log.w("로그", "패스워드 판별 진입");
                mSocketThread.write(DBManager.PW); // 변경된 구문 // 입력된 PW 서버에 보냄


                Log.w("로그", "" + DBManager.PW);


                InputStream in3 = SocketThread.socket.getInputStream();
                BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
                String echoPW = br3.readLine(); // 대기하다 서버에서 판별값을 받음
                MainActivity.TruePW = echoPW;  // 판별값을 MAIN 에서 사용하는 매개변수에 저장


                Log.w("로그 서버에서 받은 PW 판별 값 : ", "" + echoPW);

                //////////////////////////추가된 구문////////////////////////////////////
                mSocketThread.write("wait Schedule data");  // 스케쥴 데이터 받기
                InputStream in4 = SocketThread.socket.getInputStream();
                BufferedReader br4 = new BufferedReader(new InputStreamReader(in4));
                DBManager.schedule_data = br4.readLine(); // 대기하다 서버에서 판별값을 받음
                Log.w("로그", ""+DBManager.schedule_data);

                mSocketThread.write("wait RealStudy data"); // 실제 학습시간 데이터 받기
                InputStream in5 = SocketThread.socket.getInputStream();
                BufferedReader br5 = new BufferedReader(new InputStreamReader(in5));
                DBManager.Realstudy_data = br5.readLine(); // 대기하다 서버에서 판별값을 받음
                Log.w("로그", ""+DBManager.Realstudy_data);

                mSocketThread.write(DBManager.ID); // 변경된 구문
                Log.w("로그", "보낸 아이디"+ DBManager.ID);

                InputStream in6 = SocketThread.socket.getInputStream();
                BufferedReader br6 = new BufferedReader(new InputStreamReader(in2));
                ScheduleDBManager.realtime =Integer.parseInt(br6.readLine()); // 대기하다 서버에서 판별값을 받음 // 변경 전


                Log.w("test", "mytime1 :" + ScheduleDBManager.realtime);

                //////////////////////////////////////////////////////////////////////////

            }

            else if(echoID.equals("0")) {
                MainActivity.TruePW = "0";
                Log.w("로그", "PW 판별 값 : " + MainActivity.TruePW);
            }
            else if(echoID.equals("")) {
                MainActivity.TruePW = "";
                Log.w("로그 : ", "PW 판별 값 :"+ MainActivity.TruePW );
            }


        } catch (Exception e) {
            e.printStackTrace();
            Log.w("로그 버퍼", "버퍼생성 잘못됨");
        }
        Log.w("로그 버퍼", "버퍼생성 잘됨");
    }
}

class SingUp extends  Thread{    // 회원가입 소켓 통신
    SocketThread mSocketThread = SocketThread.get();
    String readData = null;

    @Override
    public void run() {
        super.run();

        try {

            Log.w("로그", "회원가입 클래스 진입");  // 버튼을 판별하기 위한 소켓 통신
            mSocketThread.write("2");
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String Lbtn = br1.readLine();
            Log.w("로그", ""+Lbtn);

            Log.w("로그", "Server로 보낸 시리얼 번호 : "+DBManager.serialnum);
            mSocketThread.write(DBManager.serialnum); // 시리얼 넘버
            InputStream in4 = SocketThread.socket.getInputStream();
            BufferedReader br4 = new BufferedReader(new InputStreamReader(in4));
            String SN = br4.readLine();
            Log.w("로그", "" + SN);

            Log.w("로그", "Server로 보낸 핸드폰 번호 : "+DBManager.phonenum);
            mSocketThread.write(DBManager.phonenum); // 핸드폰 번호
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String PH = br2.readLine();
            Log.w("로그", "" + PH);

            Log.w("로그", "Server로 보낸 비밀 번호 : "+DBManager.pw2);
            mSocketThread.write(DBManager.pw2); // 비밀 번호
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String PW = br3.readLine();
            Log.w("로그", "" + PW);




        }catch (Exception e) {

        }
    }
}



class fr_add extends  Thread{    // 친구추가 소켓 통신
    SocketThread mSocketThread = SocketThread.get();
    String readData = null;
    @Override
    public void run() {
        super.run();

        try {
            Thread.sleep(350);

            Log.d("로그", "친구추가 클래스 진입");  // 버튼을 판별하기 위한 소켓 통신
            mSocketThread.write("6");
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String Abtn = br1.readLine();

            Log.w("로그", ""+Abtn);

            Log.d("test", "null이니? : "+DBManager.fpnum);
            mSocketThread.write(DBManager.fpnum);
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            schedule.st_time = Integer.parseInt(br3.readLine());
            Log.w("realtime", ""+schedule.st_time);


        }catch (Exception e) {

        }
    }
}

class Date extends Thread{  // 스케줄 저장 알고리즘
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();

        try{
            /////////////// 버튼 구별 /////////////////////
            mSocketThread.write("3");
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echobt = br1.readLine();
            Log.d("TEST", ""+echobt);

            /////////////// 회원 전화번호 보내기 ////////////
            mSocketThread.write(DBManager.ID);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID = br2.readLine();
            Log.d("TEST", ""+echoID);

            /////////////회원 스케줄 보내기//////////////////
            mSocketThread.write(DBManager.s_tv);
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String echoDate = br3.readLine();
            Log.d("TEST", ""+echoDate);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

//class MyRank extends Thread{ //내 기록 받아오기
//    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
//    String readData = null;
//    static String mytime;
//    @Override
//    public void run() {
//        super.run();
//
//        try{
//            mSocketThread.write(DBManager.ID); //id를 보내서
//            InputStream in1 = SocketThread.socket.getInputStream();
//            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
//            mytime = br1.readLine(); //내 기록을 받아온다
////            schedule.myst_time = Integer.parseInt(br1.readLine());
//            Log.d("TEST", "mytime2: "+mytime);
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}