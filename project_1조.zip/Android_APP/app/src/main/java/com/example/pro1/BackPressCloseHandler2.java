package com.example.pro1;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;


public class BackPressCloseHandler2 {
    private long backKeyPressedTime = 0;
    private Toast toast;
    private Activity activity;

    public BackPressCloseHandler2(Activity context) {
        this.activity = context;
    }


    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2000) {
            backKeyPressedTime = System.currentTimeMillis();
            showGuide();
            return;
        }
        if (System.currentTimeMillis() <= backKeyPressedTime + 2000) {
            Intent intent = new Intent(activity.getApplicationContext(), MainActivity.class);
            MainActivity.desCount--;
            schedule.scCount++;
            activity.startActivity(intent);
            activity.finish();

            toast.cancel();
        }
    }


    public void showGuide() {
        toast = Toast.makeText(activity, "\'뒤로\'버튼을 한번 더 누르시면 로그아웃 됩니다.", Toast.LENGTH_SHORT);
        toast.show();
    }
}