package com.example.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class join extends AppCompatActivity {

    static String TruePN = "";
    static String Truepw1 = "";
    static String Truepw2 = "";
    static String TrueSN = "";
    private BackPressCloseHandler3 backPressCloseHandler3;        // 처음 화면으로 되돌아가는 기능
    @Override
    public void onCreate(Bundle savedInstanceState) {
        backPressCloseHandler3 = new BackPressCloseHandler3(this);  // 처음 화면으로 되돌아가는 기능
        super.onCreate(savedInstanceState);
        setContentView(R.layout.join);
        setTitle("회원가입");

        final EditText phoneEt = findViewById(R.id.phoneEt);
        final EditText pw1 = findViewById(R.id.pw1);
        final EditText pw2 = findViewById(R.id.pw2);
        final EditText Serialnum = findViewById(R.id.serialnum);
        Button joinb = findViewById(R.id.joinb);




        joinb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = 0;

                if (phoneEt.getText().toString().equals("") || pw1.getText().toString().equals("") || pw2.getText().toString().equals("") || Serialnum.getText().toString().equals("")) {
                    Toast.makeText(join.this, "입력칸을 모두 채워주세요.", Toast.LENGTH_LONG).show();
                } else if (!pw1.getText().toString().equals(pw2.getText().toString())) {
                    Toast.makeText(join.this, "비밀번호값이 다릅니다. 다시 입력해주세요.", Toast.LENGTH_LONG).show();
                } else {

                    DBManager mDBDbManager = DBManager.getInstance();
                    mDBDbManager.setOutput2(phoneEt.getText().toString(), pw2.getText().toString(), Serialnum.getText().toString());
                    while(true) {
                        try {
                            count++;
                            Thread.sleep(250);
                            if(count==5)
                                break;
                        } catch (Exception e) {

                        }
                    }
                    Toast.makeText(join.this, "회원가입되었습니다. 로그인해주세요", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    MainActivity.desCount--;
                    startActivity(intent);
                    finish();
                }


            }
        });

    }

    @Override
    public void onBackPressed() { // 처음화면으로 되돌아가는 기능
        backPressCloseHandler3.onBackPressed();
    }

}


