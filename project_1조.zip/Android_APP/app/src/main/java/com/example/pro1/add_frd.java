package com.example.pro1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class add_frd extends AppCompatActivity {

    String dbName = "addfrd.db";
    String tableName = "addfr";
    String dbName3 = "addfrd.db";
    String tableName3 = "addfr";
    static String TrueTime;
    static String savename;
    static int num = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_frd);

        setTitle("친구추가");

        final EditText phonenum = findViewById(R.id.phonenum);
        final EditText name = findViewById(R.id.name);

        Button savebtn = findViewById(R.id.savebtn);

        final ScheduleDBManager mDB = new ScheduleDBManager();
        boolean isDBConnect2 = mDB.setScheduleDB(this, tableName, dbName);
        if (!isDBConnect2)
            finish();

        final ScheduleDBManager mDB3 = new ScheduleDBManager();
        boolean isDBConnect3 = mDB.setScheduleDB(this, tableName3, dbName3);
        if (!isDBConnect3)
            finish();

        savebtn.setOnClickListener(new View.OnClickListener() {
//            int num = 0;

            @Override
            public void onClick(View v) {
                Log.d("test", "추가하기 버튼눌림");
                if (num == 0) {

                    try{
                        Thread.sleep(250);
                    }catch (Exception e) {

                    }

                    mDB3.inserfrd("0000", "null", 0, tableName3);

                    Log.d("test","num:"+num);
                    if (phonenum.getText().toString().equals("") && name.getText().toString().equals("")) {
                        Toast.makeText(add_frd.this, "입력칸을 모두 채워주세요.", Toast.LENGTH_LONG).show();
                    } else {
                        num++;
                        DBManager mDBDbManager = DBManager.getInstance();
                        Log.d("test","null인지 확인 : "+phonenum.getText().toString());
                        mDBDbManager.setOutput3(phonenum.getText().toString());

                        String s_PN = phonenum.getText().toString();
                        String savename = name.getText().toString();

                        Intent intent = new Intent();
                        intent.putExtra("savename", savename);
                        setResult(RESULT_OK, intent);
                        schedule.scCount--;
                        finish();

                    }
                } else if(num!=0){
                    Log.d("test","else ");
                    try{
                        Thread.sleep(250);
                    }catch (Exception e) {

                    }
                    if (phonenum.getText().toString().equals("") && name.getText().toString().equals("")) {
                        Toast.makeText(add_frd.this, "입력칸을 모두 채워주세요.", Toast.LENGTH_LONG).show();
                    } else {
                        DBManager mDBDbManager = DBManager.getInstance();
                        Log.d("test","null인지 확인 : "+phonenum.getText().toString());
                        mDBDbManager.setOutput3(phonenum.getText().toString());

                        Toast.makeText(add_frd.this, "친구추가 되었습니다.", Toast.LENGTH_LONG).show();

                        String s_PN = phonenum.getText().toString();
                        String savename = name.getText().toString();

                        Intent intent = new Intent();
                        intent.putExtra("savename", savename);
                        setResult(RESULT_OK, intent);
                        schedule.scCount--;
                        finish();

                    }
                }
            }
        });

    }
}
