package com.example.pro1;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import static android.app.Activity.RESULT_OK;

public class ScheduleDBManager {
    private DatabaseHelper helper;
    int dbVersion = 3; // 데이터베이스 버전
    static SQLiteDatabase db;
    String tag = "SQLite";



    boolean setScheduleDB(Context mContext, String tableName, String dbName) {
        helper = new DatabaseHelper(
                mContext,  // 현재 화면의 제어권자
                dbName,// db 이름
                null,  // 커서팩토리-null : 표준커서가 사용됨
                dbVersion);       // 버전
        try {
            db = helper.getWritableDatabase(); // 읽고 쓸수 있는 DB
            //db = helper.getReadableDatabase(); // 읽기 전용 DB select문
            Log.d("test", "getWritableDatabase");
        } catch (SQLiteException e) {
            e.printStackTrace();
            Log.e(tag, "데이터베이스를 얻어올 수 없음");
            return false;
        }
        return true;


    }

    void DBinsert(String date_text, String s_subnum, String s_time, String tableName) {
        ContentValues values = new ContentValues();
        // 키,값의 쌍으로 데이터 입력
        values.put("date_text", date_text);
        values.put("s_subnum", s_subnum);
        values.put("s_time", s_time);

        long result = db.insert(tableName, null, values);
        Log.d(tag, "입력 성공했음");

        schedule.textView.setText(result + "번째 row insert 성공했음");

        Log.d("test", "" + date_text);
        Log.d("test", "" + s_subnum);
        Log.d("test", "" + s_time);

        Log.d("test", "" + result);


    }//공부계획추가하는 인서트문

    void select(String tableName) {
        Cursor c = db.query(tableName, null, null, null, null, null, null);
        while (c.moveToNext()) {
            String date = c.getString(1);

//            int num=0;
//            num=schedule.tv.getLineCount()-1;
//            String _num=Integer.toString(num);
//            schedule.c_num.setText(_num);


            schedule.tv.append("\n" + "♥" + "date:" + date);
        }
    }

    void insert(String date, String tableName) {
        ContentValues values = new ContentValues();
        // 키,값의 쌍으로 데이터 입력
        values.put("date", date);

        long result = db.insert(tableName, null, values);
        Log.d(tag, "입력 성공했음");
        schedule.tv.setText("입력 성공했음");




    }

    void delete(String s_date, String tableName) {

        int result = db.delete(tableName, "date=?", new String[]{s_date});

        Log.d(tag, result + "개 row delete 성공");

        schedule.tv.setText(result + "개 row delete 성공");
        select(tableName);
    }
    //일정추가하는 insert select delete문

    void addview(String tableName2) {

        Log.d("test","커서문 못넘음");
        Cursor cursor = db.query(tableName2, null, null, null, null, null, null);
        Log.d("test","커서문 넘음");

        while (cursor.moveToNext()) {
            int id=cursor.getInt(0);
            String date_text = cursor.getString(1);
            String s_subnum = cursor.getString(2);
            String s_time = cursor.getString(3);

            schedule.DBdate.append(id +".              "+ date_text + "                  " + s_subnum + "개                  " + s_time + "시간\n");

        }
        Log.d("test", "행추가클릭");
    }

}
