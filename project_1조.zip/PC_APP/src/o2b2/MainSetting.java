package o2b2;

import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;

public class MainSetting extends JFrame{
	
	MainSetting(){
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Container contentPane = getContentPane();
	
	contentPane.setLayout(null); // ��ġ������ ����
	}
}
